Placez vos .jar de mods ici, puis lancez scripts/make_payload_zip.ps1 pour créer mods_payload.zip.
